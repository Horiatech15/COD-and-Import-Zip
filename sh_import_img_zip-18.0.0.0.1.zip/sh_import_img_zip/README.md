About
============
This module will help you to import the bulk of images from a zip file. If you have many images and you want to update that all on one shot so our module will help you to archive that very easily. you just need to manage all image files in one zip and need to select that zip and import it, it will auto-update all images. this module will be useful to update image for the product, customer/vendor/contact and employes. you can import images by name, reference, barcode and IDS depends on partner, product and employee.


External Dependencies Installation  
======================================

For Extract data from excel sheet you have to install "xlrd" library on your system. Following command 

For Python2 : ----     sudo pip install xlrd

For Python3 : ----     sudo pip3 install xlrd



Installation
============
1) Copy module files to addon folder.
2) Restart odoo service (sudo service odoo-server restart).
3) Go to your odoo instance and open apps (make sure to activate debug mode).
4) click on update app list. 
5) search module name and hit install button.

Softhealer Technologies Support Team
=====================================
Skype: live:softhealertechnologies
What's app: +917984575681
E-Mail: suppport@softhealer.com
Website: https://softhealer.com
