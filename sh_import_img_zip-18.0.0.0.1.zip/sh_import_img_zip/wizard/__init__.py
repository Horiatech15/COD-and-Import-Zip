# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.

from . import import_img_zip_wizard
