Website Cash on Delivery COD | COD | Website COD | Cash on Delivery
===================================================
-   This Odoo app enables the Cash On Delivery (COD) payment method option in website transactions. If you operate an Odoo website, ecommerce platform, 
    or online store and wish to offer your customers the option to pay via cash on delivery, this module is a suitable choice. With this app, customers 
    or visitors to your webshop can purchase products using the cash on delivery payment method. This payment method is integrated as a separate payment 
    provider in the Odoo backend. Additionally, you can customize delivery charges associated with the COD payment method to meet your business requirements.

Installation
============
- Copy website_cod_payment module to addons folder
- Install the module normally like other modules.